# Importación de las librerías necesarias para la realización del análisis de los datos

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import shutil
import datetime as dt
from scipy import stats
from matplotlib import rc
from scipy.stats import chisquare